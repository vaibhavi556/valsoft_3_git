<?php get_header(); ?>

      <div id="content">
          <article
            id="post-1269"
            class="post-1269 page type-page status-publish hentry"
          >
            <div class="wpb-content-wrapper">
              <div
                id="podcast-section"
                class="vc_row wpb_row vc_row-fluid flex-section-wrapper"
              >
                <div
                  class="container custom-container wpb_column vc_column_container vc_col-sm-12"
                >
                  <div class="vc_column-inner">
                    <div class="wpb_wrapper">
                      <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div
                          class="content-center wpb_column vc_column_container vc_col-sm-12"
                        >
                          <div class="vc_column-inner vc_custom_1684935445088">
                            <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element">
                                <div class="wpb_wrapper">
                                  <div
                                    class="eds-animate edsanimate-sis-hidden"
                                    data-eds-entry-animation="fadeInDown"
                                    data-eds-entry-delay="0"
                                    data-eds-entry-duration="0.5"
                                    data-eds-entry-timing="linear"
                                    data-eds-exit-animation=""
                                    data-eds-exit-delay=""
                                    data-eds-exit-duration=""
                                    data-eds-exit-timing=""
                                    data-eds-repeat-count="1"
                                    data-eds-keep="yes"
                                    data-eds-animate-on="scroll"
                                    data-eds-scroll-offset="75"
                                  >
                                    <h2>
                                      Listen: Learn about M&amp;A the Valsoft
                                      Way as CEO Sam Youssef Discusses His
                                      Philosophy on the M&amp;A Science Podcast
                                    </h2>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div
                        class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-equal-height vc_row-o-content-middle vc_row-flex"
                      >
                        <div
                          class="sound-wave-container wpb_column vc_column_container vc_col-sm-6 vc_col-xs-12 vc_col-has-fill "
                        >
                          <div class="vc_column-inner vc_custom_1684952324199">
                            <div class="wpb_wrapper">
                              <div class="wpb_raw_code wpb_raw_js">
                                <div class="wpb_wrapper">
                                  
                                </div>
                              </div>
                              <div
                                class="wpb_raw_code wpb_content_element wpb_raw_html"
                              >
                                <div class="wpb_wrapper">
                                  <div
                                    class="eds-animate edsanimate-sis-hidden"
                                    data-eds-entry-animation="fadeInDown"
                                    data-eds-entry-delay="0"
                                    data-eds-entry-duration="0.5"
                                    data-eds-entry-timing="linear"
                                    data-eds-exit-animation=""
                                    data-eds-exit-delay=""
                                    data-eds-exit-duration=""
                                    data-eds-exit-timing=""
                                    data-eds-repeat-count="1"
                                    data-eds-keep="yes"
                                    data-eds-animate-on="scroll"
                                    data-eds-scroll-offset="75"
                                  >
                                    <div class="sound-wave">
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.423892s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.421633s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.528905s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.433038s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.567036s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.253808s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.269063s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.491023s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.50669s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.553431s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.275957s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.304263s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.494599s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.601031s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.290877s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.335373s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.464535s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.288039s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.242996s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.310669s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.628034s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.313342s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.343278s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.660039s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.363048s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.66499s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.237467s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.341263s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.257793s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.261776s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.552605s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.651782s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.482707s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.538854s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.416216s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.258972s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.306741s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.350732s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.255957s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.593398s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.62243s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.503511s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.232372s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.540145s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.357101s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.236314s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.339355s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.33894s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.483528s"
                                      ></div>
                                      <div
                                        class="bar"
                                        style="animation-duration: 0.24499s"
                                      ></div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6">
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div
                                class="wpb_video_widget wpb_content_element video_id_658c0a93ad983"
                              >
                                <div class="wpb_wrapper">
                                  <div class="wpb_video_wrapper">
                                    <div
                                      class="video-placeholder-youtube"
                                      data-cky-tag="video-placeholder"
                                      id="TzbKaouc"
                                      style="
                                        width: 540px;
                                        height: 304px;
                                        background-image: linear-gradient(
                                            rgba(76, 72, 72, 0.7),
                                            rgba(76, 72, 72, 0.7)
                                          ),
                                          url('<?php echo get_template_directory_uri();?>/https://img.youtube.com/vi/84t7koaOvns/maxresdefault.jpg');
                                      "
                                    >
                                    <iframe width="560" height="315" src="<?php echo get_template_directory_uri();?>/https://www.youtube.com/embed/84t7koaOvns?si=IHFq2lryix1qUYxO" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                                      <p
                                        class="video-placeholder-text-youtube"
                                        data-cky-tag="placeholder-title"
                                        style="
                                          display: block;
                                          border-color: rgb(0, 0, 0);
                                          background-color: rgb(0, 0, 0);
                                          color: rgb(255, 255, 255);
                                        "
                                      >
                                        Please accept cookies to access this
                                        content
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                id="make-us-different-section"
                class="vc_row wpb_row vc_row-fluid what-makes-us-different"
              >
                <div
                  class="container custom-container xs-pb-50 pb-40 wpb_column vc_column_container vc_col-sm-12"
                >
                  <div class="vc_column-inner">
                    <div class="wpb_wrapper">
                      <div class="wpb_text_column wpb_content_element">
                        <div class="wpb_wrapper">
                          <h2>
                            <div
                              class="eds-animate edsanimate-sis-hidden"
                              data-eds-entry-animation="fadeInDown"
                              data-eds-entry-delay="0"
                              data-eds-entry-duration="0.5"
                              data-eds-entry-timing="linear"
                              data-eds-exit-animation=""
                              data-eds-exit-delay=""
                              data-eds-exit-duration=""
                              data-eds-exit-timing=""
                              data-eds-repeat-count="1"
                              data-eds-keep="yes"
                              data-eds-animate-on="scroll"
                              data-eds-scroll-offset="75"
                            >
                              What’s in It for You
                            </div>
                          </h2>
                        </div>
                      </div>
                      <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-6">
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element">
                                <div class="wpb_wrapper">
                                  <div
                                    class="eds-animate edsanimate-sis-hidden"
                                    data-eds-entry-animation="fadeIn"
                                    data-eds-entry-delay="0"
                                    data-eds-entry-duration="0.5"
                                    data-eds-entry-timing="linear"
                                    data-eds-exit-animation=""
                                    data-eds-exit-delay=""
                                    data-eds-exit-duration=""
                                    data-eds-exit-timing=""
                                    data-eds-repeat-count="1"
                                    data-eds-keep="yes"
                                    data-eds-animate-on="scroll"
                                    data-eds-scroll-offset="75"
                                  >
                                    <div class="section-icon">
                                      <noscript
                                        ><img
                                          decoding="async"
                                          src="<?php echo get_template_directory_uri();?>/assets/images/assets/images/home-house-blue.svg"
                                          alt="A permanent home for your business" /></noscript
                                      ><img
                                        class="lazyload"
                                        decoding="async"
                                        src="<?php echo get_template_directory_uri();?>/data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                        data-src="<?php echo get_template_directory_uri();?>/assets/images/home-house-blue.svg"
                                        alt="A permanent home for your business"
                                      />
                                    </div>
                                    <div class="section-content">
                                      <h4>
                                        A permanent home for your business
                                      </h4>
                                      <p></p>
                                      <p class="pf0">
                                        <span class="cf0"
                                          >Our decentralized, hold-forever
                                          philosophy provides a solid foundation
                                          for development, improved operational
                                          efficiency, and unwavering support for
                                          employees and customers, all while
                                          maintaining independence.</span
                                        >
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div
                          class="xs-mt-35 wpb_column vc_column_container vc_col-sm-6"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element">
                                <div class="wpb_wrapper">
                                  <div
                                    class="eds-animate edsanimate-sis-hidden"
                                    data-eds-entry-animation="fadeIn"
                                    data-eds-entry-delay="0"
                                    data-eds-entry-duration="0.5"
                                    data-eds-entry-timing="linear"
                                    data-eds-exit-animation=""
                                    data-eds-exit-delay=""
                                    data-eds-exit-duration=""
                                    data-eds-exit-timing=""
                                    data-eds-repeat-count="1"
                                    data-eds-keep="yes"
                                    data-eds-animate-on="scroll"
                                    data-eds-scroll-offset="75"
                                  >
                                    <div class="section-icon">
                                      <noscript
                                        ><img
                                          decoding="async"
                                          src="<?php echo get_template_directory_uri();?>/assets/images/home-operation-blue.svg"
                                          alt="Operational expertise" /></noscript
                                      ><img
                                        class="lazyload"
                                        decoding="async"
                                        src="<?php echo get_template_directory_uri();?>/data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                        data-src="<?php echo get_template_directory_uri();?>/assets/images/home-operation-blue.svg"
                                        alt="Operational expertise"
                                      />
                                    </div>
                                    <div class="section-content">
                                      <h4>Operational expertise</h4>
                                      <p></p>
                                      <p class="pf0">
                                        <span class="cf0"
                                          >With our resources, best practices,
                                          benchmarking, business intelligence,
                                          experience, and wealth of data, we’ve
                                          established a solid foundation to
                                          develop and enhance operational
                                          efficiencies. In addition, our access
                                          to global markets opens up limitless
                                          opportunities for growth.</span
                                        >
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div
                        class="vc_row wpb_row vc_inner vc_row-fluid xs-mt-35 mt-55"
                      >
                        <div class="wpb_column vc_column_container vc_col-sm-6">
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element">
                                <div class="wpb_wrapper">
                                  <div
                                    class="eds-animate edsanimate-sis-hidden"
                                    data-eds-entry-animation="fadeIn"
                                    data-eds-entry-delay="0"
                                    data-eds-entry-duration="0.7"
                                    data-eds-entry-timing="linear"
                                    data-eds-exit-animation=""
                                    data-eds-exit-delay=""
                                    data-eds-exit-duration=""
                                    data-eds-exit-timing=""
                                    data-eds-repeat-count="1"
                                    data-eds-keep="yes"
                                    data-eds-animate-on="scroll"
                                    data-eds-scroll-offset="75"
                                  >
                                    <div class="section-icon">
                                      <noscript
                                        ><img
                                          decoding="async"
                                          src="<?php echo get_template_directory_uri();?>/assets/images/home-acquisition-blue.svg"
                                          alt="Seamless acquisition process" /></noscript
                                      ><img
                                        class="lazyload"
                                        decoding="async"
                                        src="<?php echo get_template_directory_uri();?>/data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                        data-src="<?php echo get_template_directory_uri();?>/assets/images/home-acquisition-blue.svg"
                                        alt="Seamless acquisition process"
                                      />
                                    </div>
                                    <div class="section-content">
                                      <h4>Seamless acquisition process</h4>
                                      <p></p>
                                      <p class="pf0">
                                        <span class="cf0"
                                          >Our efficient and comprehensive
                                          acquisition process, combined with our
                                          business optimization formula, has
                                          proven to be a successful strategy
                                          that guarantees knowledge sharing,
                                          opportunities, and growth.</span
                                        >
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div
                          class="xs-mt-35 wpb_column vc_column_container vc_col-sm-6"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element">
                                <div class="wpb_wrapper">
                                  <div
                                    class="eds-animate edsanimate-sis-hidden"
                                    data-eds-entry-animation="fadeIn"
                                    data-eds-entry-delay="0"
                                    data-eds-entry-duration="0.7"
                                    data-eds-entry-timing="linear"
                                    data-eds-exit-animation=""
                                    data-eds-exit-delay=""
                                    data-eds-exit-duration=""
                                    data-eds-exit-timing=""
                                    data-eds-repeat-count="1"
                                    data-eds-keep="yes"
                                    data-eds-animate-on="scroll"
                                    data-eds-scroll-offset="75"
                                  >
                                    <div class="section-icon">
                                      <noscript
                                        ><img
                                          decoding="async"
                                          src="<?php echo get_template_directory_uri();?>/assets/images/home-crown.svg"
                                          alt="Leaving a lasting legacy" /></noscript
                                      ><img
                                        class="lazyload"
                                        decoding="async"
                                        src="<?php echo get_template_directory_uri();?>/data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                        data-src="<?php echo get_template_directory_uri();?>/assets/images/home-crown.svg"
                                        alt="Leaving a lasting legacy"
                                      />
                                    </div>
                                    <div class="section-content">
                                      <h4>Leaving a lasting legacy</h4>
                                      <p></p>
                                      <p class="pf0">
                                        <span class="cf0"
                                          >You have built a business that you
                                          are proud of, one that employs several
                                          skilled individuals who have supported
                                          you throughout the journey. We can
                                          ensure that your legacy not only
                                          endures but flourishes. Let us take
                                          what you have built to the next
                                          level.</span
                                        >
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="wpb_text_column wpb_content_element">
                        <div class="wpb_wrapper">
                          <div
                            class="eds-animate edsanimate-sis-hidden"
                            data-eds-entry-animation="fadeInDown"
                            data-eds-entry-delay="0"
                            data-eds-entry-duration="0.5"
                            data-eds-entry-timing="linear"
                            data-eds-exit-animation=""
                            data-eds-exit-delay=""
                            data-eds-exit-duration=""
                            data-eds-exit-timing=""
                            data-eds-repeat-count="1"
                            data-eds-keep="yes"
                            data-eds-animate-on="scroll"
                            data-eds-scroll-offset="75"
                          >
                            <div class="action-button xs-mt-40">
                              <a
                                class="button icon_right white_font_color"
                                href="https://www.valsoftcorp.com/about/"
                                >About Us <span style='font-size:20px;'>&#8594;</span></a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div
                          class="wpb_column vc_column_container vc_col-sm-12"
                        >
                          <div class="vc_column-inner vc_custom_1688387236012">
                            <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element">
                                <div class="wpb_wrapper">
                                  <h2>
                                    <div
                                      class="eds-animate edsanimate-sis-hidden"
                                      data-eds-entry-animation="fadeInDown"
                                      data-eds-entry-delay="0"
                                      data-eds-entry-duration="0.5"
                                      data-eds-entry-timing="linear"
                                      data-eds-exit-animation=""
                                      data-eds-exit-delay=""
                                      data-eds-exit-duration=""
                                      data-eds-exit-timing=""
                                      data-eds-repeat-count="1"
                                      data-eds-keep="yes"
                                      data-eds-animate-on="scroll"
                                      data-eds-scroll-offset="75"
                                    >
                                      Valsoft in Numbers
                                    </div>
                                  </h2>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div
                          class="wpb_column vc_column_container vc_col-sm-12"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div
                                class="wpb_raw_code wpb_content_element wpb_raw_html"
                              >
                                <div class="wpb_wrapper">
                                  <div id="counter-container">
                                    <div class="inner-box">
                                      <div class="circle">
                                        <div class="circle-inner">
                                          <span
                                            ><span
                                              class="counter-value"
                                              akhi="20"
                                              >20</span
                                            >+</span
                                          >
                                          <strong>countries</strong>
                                        </div>
                                      </div>
                                    </div>
                                    <div class="inner-box">
                                      <div class="circle">
                                        <div class="circle-inner">
                                          <span
                                            ><span
                                              class="counter-value"
                                              akhi="25"
                                              >25</span
                                            >+</span
                                          ><strong>industries</strong>
                                        </div>
                                      </div>
                                    </div>
                                    <div class="inner-box">
                                      <div class="circle">
                                        <div class="circle-inner">
                                          <span
                                            ><span
                                              class="counter-value"
                                              akhi="60"
                                              >60</span
                                            >+</span
                                          ><strong>companies</strong>
                                        </div>
                                      </div>
                                    </div>
                                    <div class="inner-box">
                                      <div class="circle">
                                        <div class="circle-inner">
                                          <span
                                            ><span
                                              class="counter-value"
                                              akhi="2000"
                                              >2000</span
                                            >+</span
                                          ><strong>employees</strong>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div class="wpb_raw_code wpb_raw_js">
                                <div class="wpb_wrapper">
                                 

                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                id="brochure"
                class="vc_row wpb_row vc_row-fluid our-network-companies"
              >
                <div
                  class="container custom-container pb-0 wpb_column vc_column_container vc_col-sm-12"
                >
                  <div class="vc_column-inner">
                    <div class="wpb_wrapper">
                      <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div
                          class="text-center mb-50 wpb_column vc_column_container vc_col-sm-12"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div
                                class="wpb_raw_code wpb_content_element wpb_raw_html"
                              >
                                <div class="wpb_wrapper">
                                  <div
                                    class="eds-animate edsanimate-sis-hidden"
                                    data-eds-entry-animation="fadeIn"
                                    data-eds-entry-delay="0"
                                    data-eds-entry-duration="0.5"
                                    data-eds-entry-timing="linear"
                                    data-eds-exit-animation=""
                                    data-eds-exit-delay=""
                                    data-eds-exit-duration=""
                                    data-eds-exit-timing=""
                                    data-eds-repeat-count="1"
                                    data-eds-keep="yes"
                                    data-eds-animate-on="scroll"
                                    data-eds-scroll-offset="75"
                                  >
                                    <div class="wrap-content-brochure">
                                      <div class="content-text">
                                        <div
                                          class="eds-animate edsanimate-sis-hidden"
                                          data-eds-entry-animation="fadeIn"
                                          data-eds-entry-delay="0"
                                          data-eds-entry-duration="0.5"
                                          data-eds-entry-timing="linear"
                                          data-eds-exit-animation=""
                                          data-eds-exit-delay=""
                                          data-eds-exit-duration=""
                                          data-eds-exit-timing=""
                                          data-eds-repeat-count="1"
                                          data-eds-keep="yes"
                                          data-eds-animate-on="scroll"
                                          data-eds-scroll-offset="75"
                                        >
                                          <p>
                                            We buy, hold forever and create
                                            value for our companies by
                                            partnering with existing management.
                                            Using a proven and creative strategy
                                            based on operational excellence,
                                            best practices and access to a
                                            global network, we are committed to
                                            your success.
                                          </p>
                                        </div>
                                        <div
                                          class="inline-block eds-animate edsanimate-sis-hidden"
                                          data-eds-entry-animation="zoomIn"
                                          data-eds-entry-delay="0"
                                          data-eds-entry-duration="0.5"
                                          data-eds-entry-timing="linear"
                                          data-eds-exit-animation=""
                                          data-eds-exit-delay=""
                                          data-eds-exit-duration=""
                                          data-eds-exit-timing=""
                                          data-eds-repeat-count="1"
                                          data-eds-keep="yes"
                                          data-eds-animate-on="scroll"
                                          data-eds-scroll-offset="75"
                                        >
                                          <a
                                            href="https://www.valsoftcorp.com/wp-content/uploads/2022/12/FINAL-New-Valsoft-Brochure-A4-LONG-VERSION-OCT2022.pdf?v=c33c3d5fe84eeb015d96cd7f56f6ef86"
                                            onclick="ga('send', 'event', 'Brochure', 'Header');"
                                            class="button"
                                            target="_blank"
                                            >Why Choose Us?</a
                                          >
                                        </div>
                                      </div>
                                      <div class="content-image">
                                        <noscript
                                          ><img
                                            src="<?php echo get_template_directory_uri();?>/assets/images/triangles-home.jpg"
                                            alt="Valsoft buy hold forever" /></noscript
                                        ><img
                                          class="lazyload"
                                          src="<?php echo get_template_directory_uri();?>/data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                          data-src="<?php echo get_template_directory_uri();?>/assets/images/triangles-home.jpg"
                                          alt="Valsoft buy hold forever"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                id="we-offer-testimonials-section"
                class="vc_row wpb_row vc_row-fluid our-network-companies"
              >
                <div
                  class="container custom-container pb-0 wpb_column vc_column_container vc_col-sm-12"
                >
                  <div class="vc_column-inner">
                    <div class="wpb_wrapper">
                      <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div
                          class="text-center mb-50 wpb_column vc_column_container vc_col-sm-12"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div
                                class="wpb_text_column wpb_content_element text-center"
                              >
                                <div class="wpb_wrapper">
                                  <h2>
                                    <div
                                      class="eds-animate edsanimate-sis-hidden"
                                      data-eds-entry-animation="fadeInDown"
                                      data-eds-entry-delay="0"
                                      data-eds-entry-duration="0.5"
                                      data-eds-entry-timing="linear"
                                      data-eds-exit-animation=""
                                      data-eds-exit-delay=""
                                      data-eds-exit-duration=""
                                      data-eds-exit-timing=""
                                      data-eds-repeat-count="1"
                                      data-eds-keep="yes"
                                      data-eds-animate-on="scroll"
                                      data-eds-scroll-offset="75"
                                    >
                                      What We O<strong>ffer</strong>
                                    </div>
                                  </h2>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div
                          class="icons-container wpb_column vc_column_container vc_col-sm-12"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div
                                class="wpb_raw_code wpb_content_element wpb_raw_html"
                              >
                                <div class="wpb_wrapper">
                                  <div class="iconsContainer">
                                    <div class="iconContainer">
                                      <noscript
                                        ><img
                                          src="<?php echo get_template_directory_uri();?>/assets/images/icon-team-1.svg"
                                          alt="Marketing Team"
                                          class="iconImage" /></noscript
                                      ><img
                                        src="<?php echo get_template_directory_uri();?>/data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                        data-src="<?php echo get_template_directory_uri();?>/assets/images/icon-team-1.svg"
                                        alt="Marketing Team"
                                        class="lazyload iconImage"
                                      />
                                      <h5>Marketing<br />Team</h5>
                                    </div>
                                    <div class="iconContainer">
                                      <noscript
                                        ><img
                                          src="<?php echo get_template_directory_uri();?>/assets/images/icon-flag-1.svg"
                                          alt="Leadership Development"
                                          class="iconImage" /></noscript
                                      ><img
                                        src="<?php echo get_template_directory_uri();?>/data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                        data-src="<?php echo get_template_directory_uri();?>/assets/images/icon-flag-1.svg"
                                        alt="Leadership Development"
                                        class="lazyload iconImage"
                                      />
                                      <h5>Leadership<br />Development</h5>
                                    </div>
                                    <div class="iconContainer">
                                      <noscript
                                        ><img
                                          src="<?php echo get_template_directory_uri();?>/assets/images/icon-award-1.svg"
                                          alt="Customers Satisfaction"
                                          class="iconImage" /></noscript
                                      ><img
                                        src="<?php echo get_template_directory_uri();?>/data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                        data-src="<?php echo get_template_directory_uri();?>/assets/images/icon-award-1.svg"
                                        alt="Customers Satisfaction"
                                        class="lazyload iconImage"
                                      />
                                      <h5>Customer<br />Satisfaction</h5>
                                    </div>
                                    <div class="iconContainer">
                                      <noscript
                                        ><img
                                          src="<?php echo get_template_directory_uri();?>/assets/images/icon-internet-1.svg"
                                          alt="Global Network of Entrepreneurs"
                                          class="iconImage" /></noscript
                                      ><img
                                        src="<?php echo get_template_directory_uri();?>/data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                        data-src="<?php echo get_template_directory_uri();?>/assets/images/icon-internet-1.svg"
                                        alt="Global Network of Entrepreneurs"
                                        class="lazyload iconImage"
                                      />
                                      <h5>
                                        Global Network<br />of Entrepreneurs
                                      </h5>
                                    </div>
                                    <div class="iconContainer">
                                      <noscript
                                        ><img
                                          src="<?php echo get_template_directory_uri();?>/assets/images/icon-development-1.svg"
                                          alt="Talent Development"
                                          class="iconImage" /></noscript
                                      ><img
                                        src="<?php echo get_template_directory_uri();?>/data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                        data-src="<?php echo get_template_directory_uri();?>/assets/images/icon-development-1.svg"
                                        alt="Talent Development"
                                        class="lazyload iconImage"
                                      />
                                      <h5>Talent<br />Development</h5>
                                    </div>
                                    <div class="iconContainer">
                                      <noscript
                                        ><img
                                          src="<?php echo get_template_directory_uri();?>/assets/images/icon-discovery-1.svg"
                                          alt="A Dedicated Advisory Board"
                                          class="iconImage" /></noscript
                                      ><img
                                        src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                        data-src="<?php echo get_template_directory_uri();?>/assets/images/icon-discovery-1.svg"
                                        alt="A Dedicated Advisory Board"
                                        class="lazyload iconImage"
                                      />
                                      <h5>Dedicated<br />Advisory Board</h5>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div
                          class="wpb_column vc_column_container vc_col-sm-12"
                        >
                          <div class="vc_column-inner vc_custom_1689178228643">
                            <div class="wpb_wrapper">
                              <div
                                class="wpb_text_column wpb_content_element text-center"
                              >
                                <div class="wpb_wrapper">
                                  <h2>
                                    <div
                                      class="eds-animate edsanimate-sis-hidden"
                                      data-eds-entry-animation="fadeInDown"
                                      data-eds-entry-delay="0"
                                      data-eds-entry-duration="0.5"
                                      data-eds-entry-timing="linear"
                                      data-eds-exit-animation=""
                                      data-eds-exit-delay=""
                                      data-eds-exit-duration=""
                                      data-eds-exit-timing=""
                                      data-eds-repeat-count="1"
                                      data-eds-keep="yes"
                                      data-eds-animate-on="scroll"
                                      data-eds-scroll-offset="75"
                                    >
                                      Testimonials
                                    </div>
                                  </h2>
                                </div>
                              </div>
                              <div
                                class="wpb_raw_code wpb_content_element wpb_raw_html"
                              >
                                <div class="wpb_wrapper">
                                  <div
                                    class="eds-animate edsanimate-sis-hidden"
                                    data-eds-entry-animation="fadeIn"
                                    data-eds-entry-delay="0"
                                    data-eds-entry-duration="0.5"
                                    data-eds-entry-timing="linear"
                                    data-eds-exit-animation=""
                                    data-eds-exit-delay=""
                                    data-eds-exit-duration=""
                                    data-eds-exit-timing=""
                                    data-eds-repeat-count="1"
                                    data-eds-keep="yes"
                                    data-eds-animate-on="scroll"
                                    data-eds-scroll-offset="75"
                                  >
                                    <div
                                      class="testimonials-container slick-initialized slick-slider slick-dotted"
                                    >
                                      <div class="slick-list draggable">
                                        <div
                                          class="slick-track"
                                          style="
                                            opacity: 1;
                                            width: 7770px;
                                            transform: translate3d(
                                              -2220px,
                                              0px,
                                              0px
                                            );
                                          "
                                        >
                                          <div
                                            class="slick-slide slick-cloned"
                                            data-slick-index="-1"
                                            id=""
                                            aria-hidden="true"
                                            style="width: 1110px"
                                            tabindex="-1"
                                          >
                                            <div class="testimonial-card">
                                              <div class="body-container">
                                                <div class="quote-container">
                                                  <svg
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    width="24"
                                                    height="24"
                                                    viewBox="0 0 24 24"
                                                  >
                                                    <path
                                                      class="icon-quote"
                                                      d="M9.983 3v7.391c0 5.704-3.731 9.57-8.983 10.609l-.995-2.151c2.432-.917 3.995-3.638 3.995-5.849h-4v-10h9.983zm14.017 0v7.391c0 5.704-3.748 9.571-9 10.609l-.996-2.151c2.433-.917 3.996-3.638 3.996-5.849h-3.983v-10h9.983z"
                                                    ></path>
                                                  </svg>
                                                </div>
                                                <div class="person-quote">
                                                  <p>
                                                    "We are very proud of what
                                                    we've accomplished to date
                                                    and are excited at the
                                                    prospect of continuing to
                                                    build with Valsoft. Rarely
                                                    do we find such cultural
                                                    compatibility in a partner,
                                                    and we believe that this
                                                    will immediately bear fruit
                                                    as we continue our push to
                                                    be a leader in the
                                                    industry."
                                                  </p>
                                                </div>
                                              </div>
                                              <div class="footer-container">
                                                <div
                                                  class="person-image background-person-michael"
                                                ></div>
                                                <h3 class="person-h3">
                                                  Michael Hollinger
                                                </h3>
                                                <h4 class="person-h4">
                                                  CEO of WiSys
                                                </h4>
                                              </div>
                                            </div>
                                          </div>
                                          <div
                                            class="slick-slide"
                                            data-slick-index="0"
                                            aria-hidden="true"
                                            style="width: 1110px"
                                            tabindex="-1"
                                            role="tabpanel"
                                            id="slick-slide10"
                                            aria-describedby="slick-slide-control10"
                                          >
                                            <div class="testimonial-card">
                                              <div class="body-container">
                                                <div class="quote-container">
                                                  <svg
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    width="24"
                                                    height="24"
                                                    viewBox="0 0 24 24"
                                                  >
                                                    <path
                                                      class="icon-quote"
                                                      d="M9.983 3v7.391c0 5.704-3.731 9.57-8.983 10.609l-.995-2.151c2.432-.917 3.995-3.638 3.995-5.849h-4v-10h9.983zm14.017 0v7.391c0 5.704-3.748 9.571-9 10.609l-.996-2.151c2.433-.917 3.996-3.638 3.996-5.849h-3.983v-10h9.983z"
                                                    ></path>
                                                  </svg>
                                                </div>
                                                <div class="person-quote">
                                                  <p>
                                                    "Valsoft is the perfect
                                                    partner to support the next
                                                    phase of growth for Kivuto.
                                                    The need for academic
                                                    institutions to embrace
                                                    digital education solutions
                                                    has grown exponentially in
                                                    recent years, and Kivuto is
                                                    a key player in enabling
                                                    schools and universities to
                                                    provide a world-class
                                                    solution for students,
                                                    staff, and faculty in the
                                                    management and distribution
                                                    of academic digital assets.
                                                    We have a critical role to
                                                    play in our space, the
                                                    opportunity for growth is
                                                    substantial, and as such, we
                                                    look forward to embracing
                                                    this opportunity with the
                                                    support and resources
                                                    offered by a global company
                                                    such as Valsoft."
                                                  </p>
                                                </div>
                                              </div>
                                              <div class="footer-container">
                                                <div
                                                  class="person-image background-person-mark"
                                                ></div>
                                                <h3 class="person-h3">
                                                  Mark McKenzie
                                                </h3>
                                                <h4 class="person-h4">
                                                  CEO Kivuto
                                                </h4>
                                              </div>
                                            </div>
                                          </div>
                                          <div
                                            class="slick-slide slick-current slick-active"
                                            data-slick-index="1"
                                            aria-hidden="false"
                                            style="width: 1110px"
                                            tabindex="0"
                                            role="tabpanel"
                                            id="slick-slide11"
                                            aria-describedby="slick-slide-control11"
                                          >
                                            <div class="testimonial-card">
                                              <div class="body-container">
                                                <div class="quote-container">
                                                  <svg
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    width="24"
                                                    height="24"
                                                    viewBox="0 0 24 24"
                                                  >
                                                    <path
                                                      class="icon-quote"
                                                      d="M9.983 3v7.391c0 5.704-3.731 9.57-8.983 10.609l-.995-2.151c2.432-.917 3.995-3.638 3.995-5.849h-4v-10h9.983zm14.017 0v7.391c0 5.704-3.748 9.571-9 10.609l-.996-2.151c2.433-.917 3.996-3.638 3.996-5.849h-3.983v-10h9.983z"
                                                    ></path>
                                                  </svg>
                                                </div>
                                                <div class="person-quote">
                                                  <p>
                                                    "Valsoft clearly explained
                                                    its initiatives and the ways
                                                    in which Telematel's growth
                                                    could be projected. We were
                                                    talking to people who knew
                                                    exactly what we were dealing
                                                    with. They were not
                                                    outsiders to the business.
                                                    They understood the software
                                                    business perfectly and also
                                                    understood a little what
                                                    strengths or weaknesses we
                                                    might have or things we
                                                    could improve."
                                                  </p>
                                                </div>
                                              </div>
                                              <div class="footer-container">
                                                <div
                                                  class="person-image background-person-helena2"
                                                ></div>
                                                <h3 class="person-h3">
                                                  Helena Grau Font
                                                </h3>
                                                <h4 class="person-h4">
                                                  Aspire Managing Director
                                                </h4>
                                              </div>
                                            </div>
                                          </div>
                                          <div
                                            class="slick-slide"
                                            data-slick-index="2"
                                            aria-hidden="true"
                                            style="width: 1110px"
                                            tabindex="-1"
                                            role="tabpanel"
                                            id="slick-slide12"
                                            aria-describedby="slick-slide-control12"
                                          >
                                            <div class="testimonial-card">
                                              <div class="body-container">
                                                <div class="quote-container">
                                                  <svg
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    width="24"
                                                    height="24"
                                                    viewBox="0 0 24 24"
                                                  >
                                                    <path
                                                      class="icon-quote"
                                                      d="M9.983 3v7.391c0 5.704-3.731 9.57-8.983 10.609l-.995-2.151c2.432-.917 3.995-3.638 3.995-5.849h-4v-10h9.983zm14.017 0v7.391c0 5.704-3.748 9.571-9 10.609l-.996-2.151c2.433-.917 3.996-3.638 3.996-5.849h-3.983v-10h9.983z"
                                                    ></path>
                                                  </svg>
                                                </div>
                                                <div class="person-quote">
                                                  <p>
                                                    "We are very proud of what
                                                    we've accomplished to date
                                                    and are excited at the
                                                    prospect of continuing to
                                                    build with Valsoft. Rarely
                                                    do we find such cultural
                                                    compatibility in a partner,
                                                    and we believe that this
                                                    will immediately bear fruit
                                                    as we continue our push to
                                                    be a leader in the
                                                    industry."
                                                  </p>
                                                </div>
                                              </div>
                                              <div class="footer-container">
                                                <div
                                                  class="person-image background-person-michael"
                                                ></div>
                                                <h3 class="person-h3">
                                                  Michael Hollinger
                                                </h3>
                                                <h4 class="person-h4">
                                                  CEO of WiSys
                                                </h4>
                                              </div>
                                            </div>
                                          </div>
                                          <div
                                            class="slick-slide slick-cloned"
                                            data-slick-index="3"
                                            id=""
                                            aria-hidden="true"
                                            style="width: 1110px"
                                            tabindex="-1"
                                          >
                                            <div class="testimonial-card">
                                              <div class="body-container">
                                                <div class="quote-container">
                                                  <svg
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    width="24"
                                                    height="24"
                                                    viewBox="0 0 24 24"
                                                  >
                                                    <path
                                                      class="icon-quote"
                                                      d="M9.983 3v7.391c0 5.704-3.731 9.57-8.983 10.609l-.995-2.151c2.432-.917 3.995-3.638 3.995-5.849h-4v-10h9.983zm14.017 0v7.391c0 5.704-3.748 9.571-9 10.609l-.996-2.151c2.433-.917 3.996-3.638 3.996-5.849h-3.983v-10h9.983z"
                                                    ></path>
                                                  </svg>
                                                </div>
                                                <div class="person-quote">
                                                  <p>
                                                    "Valsoft is the perfect
                                                    partner to support the next
                                                    phase of growth for Kivuto.
                                                    The need for academic
                                                    institutions to embrace
                                                    digital education solutions
                                                    has grown exponentially in
                                                    recent years, and Kivuto is
                                                    a key player in enabling
                                                    schools and universities to
                                                    provide a world-class
                                                    solution for students,
                                                    staff, and faculty in the
                                                    management and distribution
                                                    of academic digital assets.
                                                    We have a critical role to
                                                    play in our space, the
                                                    opportunity for growth is
                                                    substantial, and as such, we
                                                    look forward to embracing
                                                    this opportunity with the
                                                    support and resources
                                                    offered by a global company
                                                    such as Valsoft."
                                                  </p>
                                                </div>
                                              </div>
                                              <div class="footer-container">
                                                <div
                                                  class="person-image background-person-mark"
                                                ></div>
                                                <h3 class="person-h3">
                                                  Mark McKenzie
                                                </h3>
                                                <h4 class="person-h4">
                                                  CEO Kivuto
                                                </h4>
                                              </div>
                                            </div>
                                          </div>
                                          <div
                                            class="slick-slide slick-cloned"
                                            data-slick-index="4"
                                            id=""
                                            aria-hidden="true"
                                            style="width: 1110px"
                                            tabindex="-1"
                                          >
                                            <div class="testimonial-card">
                                              <div class="body-container">
                                                <div class="quote-container">
                                                  <svg
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    width="24"
                                                    height="24"
                                                    viewBox="0 0 24 24"
                                                  >
                                                    <path
                                                      class="icon-quote"
                                                      d="M9.983 3v7.391c0 5.704-3.731 9.57-8.983 10.609l-.995-2.151c2.432-.917 3.995-3.638 3.995-5.849h-4v-10h9.983zm14.017 0v7.391c0 5.704-3.748 9.571-9 10.609l-.996-2.151c2.433-.917 3.996-3.638 3.996-5.849h-3.983v-10h9.983z"
                                                    ></path>
                                                  </svg>
                                                </div>
                                                <div class="person-quote">
                                                  <p>
                                                    "Valsoft clearly explained
                                                    its initiatives and the ways
                                                    in which Telematel's growth
                                                    could be projected. We were
                                                    talking to people who knew
                                                    exactly what we were dealing
                                                    with. They were not
                                                    outsiders to the business.
                                                    They understood the software
                                                    business perfectly and also
                                                    understood a little what
                                                    strengths or weaknesses we
                                                    might have or things we
                                                    could improve."
                                                  </p>
                                                </div>
                                              </div>
                                              <div class="footer-container">
                                                <div
                                                  class="person-image background-person-helena2"
                                                ></div>
                                                <h3 class="person-h3">
                                                  Helena Grau Font
                                                </h3>
                                                <h4 class="person-h4">
                                                  Aspire Managing Director
                                                </h4>
                                              </div>
                                            </div>
                                          </div>
                                          <div
                                            class="slick-slide slick-cloned"
                                            data-slick-index="5"
                                            id=""
                                            aria-hidden="true"
                                            style="width: 1110px"
                                            tabindex="-1"
                                          >
                                            <div class="testimonial-card">
                                              <div class="body-container">
                                                <div class="quote-container">
                                                  <svg
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    width="24"
                                                    height="24"
                                                    viewBox="0 0 24 24"
                                                  >
                                                    <path
                                                      class="icon-quote"
                                                      d="M9.983 3v7.391c0 5.704-3.731 9.57-8.983 10.609l-.995-2.151c2.432-.917 3.995-3.638 3.995-5.849h-4v-10h9.983zm14.017 0v7.391c0 5.704-3.748 9.571-9 10.609l-.996-2.151c2.433-.917 3.996-3.638 3.996-5.849h-3.983v-10h9.983z"
                                                    ></path>
                                                  </svg>
                                                </div>
                                                <div class="person-quote">
                                                  <p>
                                                    "We are very proud of what
                                                    we've accomplished to date
                                                    and are excited at the
                                                    prospect of continuing to
                                                    build with Valsoft. Rarely
                                                    do we find such cultural
                                                    compatibility in a partner,
                                                    and we believe that this
                                                    will immediately bear fruit
                                                    as we continue our push to
                                                    be a leader in the
                                                    industry."
                                                  </p>
                                                </div>
                                              </div>
                                              <div class="footer-container">
                                                <div
                                                  class="person-image background-person-michael"
                                                ></div>
                                                <h3 class="person-h3">
                                                  Michael Hollinger
                                                </h3>
                                                <h4 class="person-h4">
                                                  CEO of WiSys
                                                </h4>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      <ul
                                        class="slick-dots"
                                        style=""
                                        role="tablist"
                                      >
                                        <li class="" role="presentation">
                                          <button
                                            type="button"
                                            role="tab"
                                            id="slick-slide-control10"
                                            aria-controls="slick-slide10"
                                            aria-label="1 of 3"
                                            tabindex="-1"
                                          >
                                            1
                                          </button>
                                        </li>
                                        <li
                                          role="presentation"
                                          class="slick-active"
                                        >
                                          <button
                                            type="button"
                                            role="tab"
                                            id="slick-slide-control11"
                                            aria-controls="slick-slide11"
                                            aria-label="2 of 3"
                                            tabindex="0"
                                            aria-selected="true"
                                          >
                                            2
                                          </button>
                                        </li>
                                        <li role="presentation">
                                          <button
                                            type="button"
                                            role="tab"
                                            id="slick-slide-control12"
                                            aria-controls="slick-slide12"
                                            aria-label="3 of 3"
                                            tabindex="-1"
                                          >
                                            3
                                          </button>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                id="network-companies-section"
                class="vc_row wpb_row vc_row-fluid our-network-companies"
              >
                <div
                  class="container custom-container pb-0 wpb_column vc_column_container vc_col-sm-12"
                >
                  <div class="vc_column-inner">
                    <div class="wpb_wrapper">
                      <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div
                          class="text-center mb-50 wpb_column vc_column_container vc_col-sm-12"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div
                                class="wpb_raw_code wpb_content_element wpb_raw_html"
                              >
                                <div class="wpb_wrapper">
                                  <div
                                    class="eds-animate edsanimate-sis-hidden"
                                    data-eds-entry-animation="fadeIn"
                                    data-eds-entry-delay="0"
                                    data-eds-entry-duration="0.5"
                                    data-eds-entry-timing="linear"
                                    data-eds-exit-animation=""
                                    data-eds-exit-delay=""
                                    data-eds-exit-duration=""
                                    data-eds-exit-timing=""
                                    data-eds-repeat-count="1"
                                    data-eds-keep="yes"
                                    data-eds-animate-on="scroll"
                                    data-eds-scroll-offset="75"
                                  >
                                    <h2>Our Network of Companies</h2>
                                    <p>
                                      Did you know that Valsoft has acquired
                                      over 50 companies worldwide? We are in 10+
                                      countries, three continents across 20+
                                      industries. Our vast network of
                                      entrepreneurs around the globe provides a
                                      deep pool of expertise and opportunity
                                      that we can rely on to ensure growth.
                                    </p>
                                    <div
                                      class="inline-block eds-animate edsanimate-sis-hidden"
                                      data-eds-entry-animation="zoomIn"
                                      data-eds-entry-delay="0"
                                      data-eds-entry-duration="0.5"
                                      data-eds-entry-timing="linear"
                                      data-eds-exit-animation=""
                                      data-eds-exit-delay=""
                                      data-eds-exit-duration=""
                                      data-eds-exit-timing=""
                                      data-eds-repeat-count="1"
                                      data-eds-keep="yes"
                                      data-eds-animate-on="scroll"
                                      data-eds-scroll-offset="75"
                                    >
                                      <a
                                        href="https://www.valsoftcorp.com/our-companies/"
                                        class="button"
                                        target="_self"
                                        >Our Companies</a
                                      >
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                id="filter-map-row"
                class="vc_row wpb_row vc_row-fluid our-companies-map"
              >
                <div class="wpb_column vc_column_container vc_col-sm-12">
                  <div class="vc_column-inner">
                    <div class="wpb_wrapper">
                      <div
                        class="vc_row wpb_row vc_inner vc_row-fluid container container-margin-auto"
                      >
                        <div
                          class="container wpb_column vc_column_container vc_col-sm-12"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div
                                class="wpb_raw_code wpb_content_element wpb_raw_html vc_custom_1674055968846"
                              >
                                <div class="wpb_wrapper">
                                  <div class="filter-map">
                                    <label>Explore Our Global Reach: </label>
                                    <br />
                                    <select
                                      id="country"
                                      class="select2-hidden-accessible"
                                      name="country"
                                      tabindex="-1"
                                      aria-hidden="true"
                                    >
                                      <option value="" selected="selected">
                                        Select Country
                                      </option>
                                      <option
                                        value="Australia"
                                        data-alpha2="AU"
                                        data-alpha3="AUS"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="-27"
                                        data-longitude="133"
                                      >
                                        Australia
                                      </option>
                                      <option
                                        value="Belgium"
                                        data-alpha2="BE"
                                        data-alpha3="BEL"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="50.8333"
                                        data-longitude="4"
                                      >
                                        Belgium
                                      </option>
                                      <option
                                        value="Canada"
                                        data-alpha2="CA"
                                        data-alpha3="CAN"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="60"
                                        data-longitude="-95"
                                      >
                                        Canada
                                      </option>
                                      <option
                                        value="Denmark"
                                        data-alpha2="DK"
                                        data-alpha3="DNK"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="56"
                                        data-longitude="10"
                                      >
                                        Denmark
                                      </option>
                                      <option
                                        value="Finland"
                                        data-alpha2="FI"
                                        data-alpha3="FIN"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="64"
                                        data-longitude="26"
                                      >
                                        Finland
                                      </option>
                                      <option
                                        value="France"
                                        data-alpha2="FR"
                                        data-alpha3="FRA"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="46"
                                        data-longitude="2"
                                      >
                                        France
                                      </option>
                                      <option
                                        value="Germany"
                                        data-alpha2="DE"
                                        data-alpha3="DEU"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="51"
                                        data-longitude="9"
                                      >
                                        Germany
                                      </option>
                                      <option
                                        value="India"
                                        data-alpha2="IN"
                                        data-alpha3="IND"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="20"
                                        data-longitude="77"
                                      >
                                        India
                                      </option>
                                      <option
                                        value="Ireland"
                                        data-alpha2="IE"
                                        data-alpha3="IRL"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="53"
                                        data-longitude="-8"
                                      >
                                        Ireland
                                      </option>
                                      <option
                                        value="Italy"
                                        data-alpha2="IT"
                                        data-alpha3="ITA"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="42.8333"
                                        data-longitude="12.8333"
                                      >
                                        Italy
                                      </option>
                                      <option
                                        value="Netherlands"
                                        data-alpha2="NL"
                                        data-alpha3="NLD"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="52.5"
                                        data-longitude="5.75"
                                      >
                                        Netherlands
                                      </option>
                                      <option
                                        value="Spain"
                                        data-alpha2="ES"
                                        data-alpha3="ESP"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="40"
                                        data-longitude="-4"
                                      >
                                        Spain
                                      </option>
                                      <option
                                        value="Sweden"
                                        data-alpha2="SE"
                                        data-alpha3="SWE"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="62"
                                        data-longitude="15"
                                      >
                                        Sweden
                                      </option>
                                      <option
                                        value="Switzerland"
                                        data-alpha2="CH"
                                        data-alpha3="CHE"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="47"
                                        data-longitude="8"
                                      >
                                        Switzerland
                                      </option>
                                      <option
                                        value="United Kingdom"
                                        data-alpha2="GB"
                                        data-alpha3="GBR"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="54"
                                        data-longitude="-2"
                                      >
                                        United Kingdom
                                      </option>
                                      <option
                                        value="United States"
                                        data-alpha2="US"
                                        data-alpha3="USA"
                                        data-hb=""
                                        data-tc=""
                                        data-latitude="38"
                                        data-longitude="-97"
                                      >
                                        United States
                                      </option></select
                                    ><span
                                      class="select2 select2-container select2-container--default"
                                      dir="ltr"
                                      style="width: 100%"
                                      ><span class="selection"
                                        ><span
                                          class="select2-selection select2-selection--single"
                                          role="combobox"
                                          aria-autocomplete="list"
                                          aria-haspopup="true"
                                          aria-expanded="false"
                                          tabindex="0"
                                          aria-labelledby="select2-country-container"
                                          ><span
                                            class="select2-selection__rendered"
                                            id="select2-country-container"
                                            title="Select Country"
                                            >Select Country</span
                                          ><span
                                            class="select2-selection__arrow"
                                            role="presentation"
                                            ><b
                                              role="presentation"
                                            ></b></span></span></span
                                      ><span
                                        class="dropdown-wrapper"
                                        aria-hidden="true"
                                      ></span
                                    ></span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                id="map-row"
                class="vc_row wpb_row vc_row-fluid our-companies-map"
              >
                <div class="wpb_column vc_column_container vc_col-sm-12">
                  <div class="vc_column-inner">
                    <div class="wpb_wrapper">
                      <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div
                          class="wpb_column vc_column_container vc_col-sm-12"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div
                                class="wpb_raw_code wpb_content_element wpb_raw_html"
                              >
                                <div class="wpb_wrapper">
                                  <div id="map">
                                    <div
                                      style="height: 100%; width: 100%"
                                    >
                                                      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2798.2993832428156!2d-73.82591872335858!3d45.46377273346661!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cc93c6f246aaaab%3A0xe1ceafa617f0ee51!2sEmbrace!5e0!3m2!1sen!2sin!4v1703755242032!5m2!1sen!2sin" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                id="call-to-action-companies"
                class="vc_row wpb_row vc_row-fluid"
              >
                <div
                  class="container custom-container pt-0 wpb_column vc_column_container vc_col-sm-12"
                >
                  <div class="vc_column-inner">
                    <div class="wpb_wrapper">
                      <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div
                          class="wpb_column vc_column_container vc_col-sm-12"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element">
                                <div class="wpb_wrapper">
                                  <div
                                    class="eds-animate edsanimate-sis-hidden"
                                    data-eds-entry-animation="zoomIn"
                                    data-eds-entry-delay="0"
                                    data-eds-entry-duration="0.5"
                                    data-eds-entry-timing="linear"
                                    data-eds-exit-animation=""
                                    data-eds-exit-delay=""
                                    data-eds-exit-duration=""
                                    data-eds-exit-timing=""
                                    data-eds-repeat-count="1"
                                    data-eds-keep="yes"
                                    data-eds-animate-on="scroll"
                                    data-eds-scroll-offset="75"
                                  >
                                    <div class="action-button xs-mt-50">
                                      <a
                                        class="button icon_right"
                                        href="https://www.valsoftcorp.com/our-companies/"
                                        >Our Companies
                                        <span style='font-size:20px;'>&#8594;</span></a>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                id="ceo-message-section"
                class="vc_row wpb_row vc_row-fluid message-from-ceo"
              >
                <div
                  class="bg-images container custom-container wpb_column vc_column_container vc_col-sm-12"
                >
                  <div class="vc_column-inner">
                    <div class="wpb_wrapper">
                      <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div
                          class="wpb_column vc_column_container vc_col-sm-12"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div
                                class="wpb_raw_code wpb_content_element wpb_raw_html"
                              >
                                <div class="wpb_wrapper">
                                  <div
                                    class="eds-animate animated fadeIn"
                                    data-eds-entry-animation="fadeIn"
                                    data-eds-entry-delay="0.5"
                                    data-eds-entry-duration="1"
                                    data-eds-entry-timing="linear"
                                    data-eds-exit-animation=""
                                    data-eds-exit-delay=""
                                    data-eds-exit-duration=""
                                    data-eds-exit-timing=""
                                    data-eds-repeat-count="1"
                                    data-eds-keep="yes"
                                    data-eds-animate-on="load"
                                    data-eds-scroll-offset=""
                                    style="
                                      animation-duration: 1s !important;
                                      animation-delay: 0s !important;
                                      animation-iteration-count: 1 !important;
                                      animation-timing-function: linear !important;
                                    "
                                  >
                                    <div
                                      class="messages-container slick-initialized slick-slider slick-dotted"
                                    >
                                      <div class="slick-list draggable">
                                        <div
                                          class="slick-track"
                                          style="
                                            opacity: 1;
                                            width: 7770px;
                                            transform: translate3d(
                                              -1110px,
                                              0px,
                                              0px
                                            );
                                          "
                                        >
                                          <div
                                            class="slick-slide slick-cloned"
                                            data-slick-index="-1"
                                            id=""
                                            aria-hidden="true"
                                            style="width: 1110px"
                                            tabindex="-1"
                                          >
                                            <div class="inner-container">
                                              <div
                                                class="img-box-mobile visible-xs"
                                              >
                                                <noscript
                                                  ><img
                                                    src="<?php echo get_template_directory_uri();?>/assets/images/Michael-Assi-square.jpg"
                                                    alt="Michael Assi" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="<?php echo get_template_directory_uri();?>/assets/images/Michael-Assi-square.jpg"
                                                  alt="Michael Assi"
                                                />
                                              </div>
                                              <div class="content-box">
                                                <p>
                                                  Buy. Enhance. Grow. We live by
                                                  those words every day, working
                                                  with our teams to create
                                                  greater business value. We
                                                  take extreme pride in serving
                                                  our customers as long-term
                                                  technology partners. To us,
                                                  acquisition is more than just
                                                  a transaction; we form
                                                  long-lasting connections that
                                                  are built on trust and a
                                                  shared vision. Your employees,
                                                  customers and partners become
                                                  a part of our family. We will
                                                  work together to build upon
                                                  your legacy and take your
                                                  company to new heights.
                                                </p>
                                                <h3>Michael Assi</h3>
                                                <h4>
                                                  CEO of Aspire Software,
                                                  Operating Division of Valsoft
                                                </h4>
                                              </div>
                                              <div class="img-box hidden-xs">
                                                <noscript
                                                  ><img
                                                    src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-CEO-Message.png"
                                                    alt="Michael Assi" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-CEO-Message.png"
                                                  alt="Michael Assi"
                                                />
                                              </div>
                                            </div>
                                          </div>
                                          <div
                                            class="slick-slide slick-current slick-active"
                                            data-slick-index="0"
                                            aria-hidden="false"
                                            style="width: 1110px"
                                            tabindex="0"
                                            role="tabpanel"
                                            id="slick-slide00"
                                            aria-describedby="slick-slide-control00"
                                          >
                                            <div class="inner-container">
                                              <div
                                                class="img-box-mobile visible-xs"
                                              >
                                                <noscript
                                                  ><img
                                                    src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-square.jpg"
                                                    alt="Sam Youssef" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-square.jpg"
                                                  alt="Sam Youssef"
                                                />
                                              </div>
                                              <div class="content-box">
                                                <p>
                                                  We think the best outcomes in
                                                  business come from having an
                                                  obsessive behavior towards
                                                  making sure your customers are
                                                  absolutely thrilled when
                                                  dealing with your company.
                                                  Your customers will become
                                                  your salespeople, and they
                                                  will stay with you. This has
                                                  been our formula, plain and
                                                  simple. If you have a business
                                                  that has achieved that, we'd
                                                  like you to consider making
                                                  Valsoft the permanent home for
                                                  your business. We promise to
                                                  build upon your legacy.
                                                </p>
                                                <h3>Sam Youssef</h3>
                                                <h4>
                                                  Founder and CEO of Valsoft
                                                </h4>
                                              </div>
                                              <div class="img-box hidden-xs">
                                                <noscript
                                                  ><img
                                                    src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-CEO-Message.png"
                                                    alt="Sam Youssef" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-CEO-Message.png"
                                                  alt="Sam Youssef"
                                                />
                                              </div>
                                            </div>
                                          </div>
                                          <div
                                            class="slick-slide"
                                            data-slick-index="1"
                                            aria-hidden="true"
                                            style="width: 1110px"
                                            tabindex="-1"
                                            role="tabpanel"
                                            id="slick-slide01"
                                            aria-describedby="slick-slide-control01"
                                          >
                                            <div class="inner-container">
                                              <div
                                                class="img-box-mobile visible-xs"
                                              >
                                                <noscript
                                                  ><img
                                                    src="<?php echo get_template_directory_uri();?>/assets/images/Mounir-Hilal-square.jpg"
                                                    alt="Mounir Hilal" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="<?php echo get_template_directory_uri();?>/assets/images/Mounir-Hilal-square.jpg"
                                                  alt="Mounir Hilal"
                                                />
                                              </div>
                                              <div class="content-box">
                                                <p>
                                                  As an original board member,
                                                  I've been amazed to see the
                                                  rate at which the company has
                                                  evolved and grown over the
                                                  years. This is a true
                                                  testament to the vision and
                                                  leadership of the
                                                  organization. Our growth is
                                                  core in writing the next
                                                  chapter of the Valsoft story,
                                                  and we are set to expand and
                                                  scale our operations and
                                                  integrations teams to support
                                                  that development.
                                                </p>
                                                <h3>Mounir Hilal</h3>
                                                <h4>
                                                  President and Chief Operating
                                                  Officer
                                                </h4>
                                              </div>
                                              <div class="img-box hidden-xs">
                                                <noscript
                                                  ><img
                                                    src="/wp-content/uploads/2021/11/Mounir-Hilal-Nov-2021.png"
                                                    alt="Mounir Hilal" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="/wp-content/uploads/2021/11/Mounir-Hilal-Nov-2021.png"
                                                  alt="Mounir Hilal"
                                                />
                                              </div>
                                            </div>
                                          </div>
                                          <div
                                            class="slick-slide"
                                            data-slick-index="2"
                                            aria-hidden="true"
                                            style="width: 1110px"
                                            tabindex="-1"
                                            role="tabpanel"
                                            id="slick-slide02"
                                            aria-describedby="slick-slide-control02"
                                          >
                                            <div class="inner-container">
                                              <div
                                                class="img-box-mobile visible-xs"
                                              >
                                                <noscript
                                                  ><img
                                                    src="<?php echo get_template_directory_uri();?>/assets/images/Michael-Assi-square.jpg"
                                                    alt="Michael Assi" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="<?php echo get_template_directory_uri();?>/assets/images/Michael-Assi-square.jpg"
                                                  alt="Michael Assi"
                                                />
                                              </div>
                                              <div class="content-box">
                                                <p>
                                                  Buy. Enhance. Grow. We live by
                                                  those words every day, working
                                                  with our teams to create
                                                  greater business value. We
                                                  take extreme pride in serving
                                                  our customers as long-term
                                                  technology partners. To us,
                                                  acquisition is more than just
                                                  a transaction; we form
                                                  long-lasting connections that
                                                  are built on trust and a
                                                  shared vision. Your employees,
                                                  customers and partners become
                                                  a part of our family. We will
                                                  work together to build upon
                                                  your legacy and take your
                                                  company to new heights.
                                                </p>
                                                <h3>Michael Assi</h3>
                                                <h4>
                                                  CEO of Aspire Software,
                                                  Operating Division of Valsoft
                                                </h4>
                                              </div>
                                              <div class="img-box hidden-xs">
                                                <noscript
                                                  ><img
                                                    src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-CEO-Message.png"
                                                    alt="Michael Assi" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-CEO-Message.png"
                                                  alt="Michael Assi"
                                                />
                                              </div>
                                            </div>
                                          </div>
                                          <div
                                            class="slick-slide slick-cloned"
                                            data-slick-index="3"
                                            id=""
                                            aria-hidden="true"
                                            style="width: 1110px"
                                            tabindex="-1"
                                          >
                                            <div class="inner-container">
                                              <div
                                                class="img-box-mobile visible-xs"
                                              >
                                                <noscript
                                                  ><img
                                                    src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-square.jpg"
                                                    alt="Sam Youssef" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-square.jpg"
                                                  alt="Sam Youssef"
                                                />
                                              </div>
                                              <div class="content-box">
                                                <p>
                                                  We think the best outcomes in
                                                  business come from having an
                                                  obsessive behavior towards
                                                  making sure your customers are
                                                  absolutely thrilled when
                                                  dealing with your company.
                                                  Your customers will become
                                                  your salespeople, and they
                                                  will stay with you. This has
                                                  been our formula, plain and
                                                  simple. If you have a business
                                                  that has achieved that, we'd
                                                  like you to consider making
                                                  Valsoft the permanent home for
                                                  your business. We promise to
                                                  build upon your legacy.
                                                </p>
                                                <h3>Sam Youssef</h3>
                                                <h4>
                                                  Founder and CEO of Valsoft
                                                </h4>
                                              </div>
                                              <div class="img-box hidden-xs">
                                                <noscript
                                                  ><img
                                                    src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-CEO-Message.png"
                                                    alt="Sam Youssef" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-CEO-Message.png"
                                                  alt="Sam Youssef"
                                                />
                                              </div>
                                            </div>
                                          </div>
                                          <div
                                            class="slick-slide slick-cloned"
                                            data-slick-index="4"
                                            id=""
                                            aria-hidden="true"
                                            style="width: 1110px"
                                            tabindex="-1"
                                          >
                                            <div class="inner-container">
                                              <div
                                                class="img-box-mobile visible-xs"
                                              >
                                                <noscript
                                                  ><img
                                                    src="<?php echo get_template_directory_uri();?>/assets/images/Mounir-Hilal-square.jpg"
                                                    alt="Mounir Hilal" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="<?php echo get_template_directory_uri();?>/assets/images/Mounir-Hilal-square.jpg"
                                                  alt="Mounir Hilal"
                                                />
                                              </div>
                                              <div class="content-box">
                                                <p>
                                                  As an original board member,
                                                  I've been amazed to see the
                                                  rate at which the company has
                                                  evolved and grown over the
                                                  years. This is a true
                                                  testament to the vision and
                                                  leadership of the
                                                  organization. Our growth is
                                                  core in writing the next
                                                  chapter of the Valsoft story,
                                                  and we are set to expand and
                                                  scale our operations and
                                                  integrations teams to support
                                                  that development.
                                                </p>
                                                <h3>Mounir Hilal</h3>
                                                <h4>
                                                  President and Chief Operating
                                                  Officer
                                                </h4>
                                              </div>
                                              <div class="img-box hidden-xs">
                                                <noscript
                                                  ><img
                                                    src="/wp-content/uploads/2021/11/Mounir-Hilal-Nov-2021.png"
                                                    alt="Mounir Hilal" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="/wp-content/uploads/2021/11/Mounir-Hilal-Nov-2021.png"
                                                  alt="Mounir Hilal"
                                                />
                                              </div>
                                            </div>
                                          </div>
                                          <div
                                            class="slick-slide slick-cloned"
                                            data-slick-index="5"
                                            id=""
                                            aria-hidden="true"
                                            style="width: 1110px"
                                            tabindex="-1"
                                          >
                                            <div class="inner-container">
                                              <div
                                                class="img-box-mobile visible-xs"
                                              >
                                                <noscript
                                                  ><img
                                                    src="<?php echo get_template_directory_uri();?>/assets/images/Michael-Assi-square.jpg"
                                                    alt="Michael Assi" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="<?php echo get_template_directory_uri();?>/assets/images/Michael-Assi-square.jpg"
                                                  alt="Michael Assi"
                                                />
                                              </div>
                                              <div class="content-box">
                                                <p>
                                                  Buy. Enhance. Grow. We live by
                                                  those words every day, working
                                                  with our teams to create
                                                  greater business value. We
                                                  take extreme pride in serving
                                                  our customers as long-term
                                                  technology partners. To us,
                                                  acquisition is more than just
                                                  a transaction; we form
                                                  long-lasting connections that
                                                  are built on trust and a
                                                  shared vision. Your employees,
                                                  customers and partners become
                                                  a part of our family. We will
                                                  work together to build upon
                                                  your legacy and take your
                                                  company to new heights.
                                                </p>
                                                <h3>Michael Assi</h3>
                                                <h4>
                                                  CEO of Aspire Software,
                                                  Operating Division of Valsoft
                                                </h4>
                                              </div>
                                              <div class="img-box hidden-xs">
                                                <noscript
                                                  ><img
                                                    src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-CEO-Message.png"
                                                    alt="Michael Assi" /></noscript
                                                ><img
                                                  class="lazyload"
                                                  src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20210%20140%22%3E%3C/svg%3E"
                                                  data-src="<?php echo get_template_directory_uri();?>/assets/images/Sam-Youssef-CEO-Message.png"
                                                  alt="Michael Assi"
                                                />
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      <ul
                                        class="slick-dots"
                                        style=""
                                        role="tablist"
                                      >
                                        <li
                                          class="slick-active"
                                          role="presentation"
                                        >
                                          <button
                                            type="button"
                                            role="tab"
                                            id="slick-slide-control00"
                                            aria-controls="slick-slide00"
                                            aria-label="1 of 3"
                                            tabindex="0"
                                            aria-selected="true"
                                          >
                                            1
                                          </button>
                                        </li>
                                        <li role="presentation">
                                          <button
                                            type="button"
                                            role="tab"
                                            id="slick-slide-control01"
                                            aria-controls="slick-slide01"
                                            aria-label="2 of 3"
                                            tabindex="-1"
                                          >
                                            2
                                          </button>
                                        </li>
                                        <li role="presentation">
                                          <button
                                            type="button"
                                            role="tab"
                                            id="slick-slide-control02"
                                            aria-controls="slick-slide02"
                                            aria-label="3 of 3"
                                            tabindex="-1"
                                          >
                                            3
                                          </button>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                id="acquisitions-section"
                class="vc_row wpb_row vc_row-fluid"
              >
                <div
                  class="container custom-container wpb_column vc_column_container vc_col-sm-12"
                >
                  <div class="vc_column-inner">
                    <div class="wpb_wrapper">
                      <div
                        class="vc_row wpb_row vc_inner vc_row-fluid contact-sell-form vc_row-o-content-middle vc_row-flex"
                      >
                        <div
                          class="wpb_column vc_column_container vc_col-sm-12"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div
                                class="wpb_text_column wpb_content_element content-center text-center"
                              >
                                <div class="wpb_wrapper">
                                  <h2>
                                    <div
                                      class="eds-animate edsanimate-sis-hidden"
                                      data-eds-entry-animation="fadeInDown"
                                      data-eds-entry-delay="0"
                                      data-eds-entry-duration="0.5"
                                      data-eds-entry-timing="linear"
                                      data-eds-exit-animation=""
                                      data-eds-exit-delay=""
                                      data-eds-exit-duration=""
                                      data-eds-exit-timing=""
                                      data-eds-repeat-count="1"
                                      data-eds-keep="yes"
                                      data-eds-animate-on="scroll"
                                      data-eds-scroll-offset="75"
                                    >
                                      Latest News
                                    </div>
                                  </h2>
                                </div>
                              </div>
                              <div
                                class="wpb_raw_code wpb_content_element wpb_raw_html"
                              >
                                <div class="wpb_wrapper">
                                  <div
                                    class="acquisitions-container slick-initialized slick-slider slick-dotted"
                                    id="acquisitions-container"
                                  >
                                    <button
                                      class="slick-prev slick-arrow"
                                      aria-label="Previous"
                                      type="button"
                                      aria-disabled="false"
                                      style=""
                                    >
                                      Previous
                                    </button>
                                    <div class="slick-list draggable">
                                      <div
                                        class="slick-track"
                                        style="
                                          opacity: 1;
                                          width: 1850px;
                                          transform: translate3d(
                                            -740px,
                                            0px,
                                            0px
                                          );
                                        "
                                      >
                                        <div
                                          class="slick-slide"
                                          data-slick-index="0"
                                          aria-hidden="true"
                                          style="width: 370px"
                                          tabindex="-1"
                                          role="tabpanel"
                                          id="slick-slide20"
                                          aria-describedby="slick-slide-control20"
                                        >
                                          <div class="card-acquisitions">
                                            <a
                                              href="https://www.valsoftcorp.com/news/valsoft-corporation-strengthens-its-process-manufacturing-portfolio-with-the-acquisition-of-fusion/"
                                              tabindex="-1"
                                            >
                                              <img
                                                src="<?php echo get_template_directory_uri();?>/assets/images/Fusion-Website.jpg"
                                                alt="Valsoft Corporation Strengthens Its Process &amp; Manufacturing Portfolio With the Acquisition of Fusion"
                                              />
                                            </a>
                                            <span
                                              ><a
                                                href="https://www.valsoftcorp.com/news/valsoft-corporation-strengthens-its-process-manufacturing-portfolio-with-the-acquisition-of-fusion/"
                                                tabindex="-1"
                                                >Valsoft Corporation Strengthens
                                                Its Process &amp; Manufacturing
                                                Portfolio With the Acquisition
                                                of Fusion</a
                                              ></span
                                            >
                                          </div>
                                        </div>
                                        <div
                                          class="slick-slide"
                                          data-slick-index="1"
                                          aria-hidden="true"
                                          style="width: 370px"
                                          tabindex="-1"
                                          role="tabpanel"
                                          id="slick-slide21"
                                        >
                                          <div class="card-acquisitions">
                                            <a
                                              href="https://www.valsoftcorp.com/news/valsoft-corporation-enters-the-supply-chain-visibility-space-with-the-acquisition-of-icl/"
                                              tabindex="-1"
                                            >
                                              <img
                                                src="<?php echo get_template_directory_uri();?>/assets/images/ICL-Website.jpg"
                                                alt="Valsoft Corporation enters the Supply Chain Visibility space with the acquisition of ICL"
                                              />
                                            </a>
                                            <span
                                              ><a
                                                href="https://www.valsoftcorp.com/news/valsoft-corporation-enters-the-supply-chain-visibility-space-with-the-acquisition-of-icl/"
                                                tabindex="-1"
                                                >Valsoft Corporation enters the
                                                Supply Chain Visibility space
                                                with the acquisition of ICL</a
                                              ></span
                                            >
                                          </div>
                                        </div>
                                        <div
                                          class="slick-slide slick-active"
                                          data-slick-index="2"
                                          aria-hidden="false"
                                          style="width: 370px"
                                          tabindex="-1"
                                          role="tabpanel"
                                          id="slick-slide22"
                                        >
                                          <div class="card-acquisitions">
                                            <a
                                              href="https://www.valsoftcorp.com/news/valsoft-corporation-introduces-its-industrial-erp-portfolio-with-the-acquisition-of-jbl-solutions/"
                                              tabindex="0"
                                            >
                                              <img
                                                src="<?php echo get_template_directory_uri();?>/assets/images/JBL-Website.jpg"
                                                alt="Valsoft Corporation Introduces Its Industrial ERP Portfolio With the Acquisition of JBL Solutions"
                                              />
                                            </a>
                                            <span
                                              ><a
                                                href="https://www.valsoftcorp.com/news/valsoft-corporation-introduces-its-industrial-erp-portfolio-with-the-acquisition-of-jbl-solutions/"
                                                tabindex="0"
                                                >Valsoft Corporation Introduces
                                                Its Industrial ERP Portfolio
                                                With the Acquisition of JBL
                                                Solutions</a
                                              ></span
                                            >
                                          </div>
                                        </div>
                                        <div
                                          class="slick-slide slick-current slick-active"
                                          data-slick-index="3"
                                          aria-hidden="false"
                                          style="width: 370px"
                                          tabindex="0"
                                          role="tabpanel"
                                          id="slick-slide23"
                                          aria-describedby="slick-slide-control21"
                                        >
                                          <div class="card-acquisitions">
                                            <a
                                              href="https://www.valsoftcorp.com/news/valsoft-corporation-enters-the-marketing-automation-space-with-the-acquisition-of-demandbridge/"
                                              tabindex="0"
                                            >
                                              <img
                                                src="<?php echo get_template_directory_uri();?>/assets/images/DemandBridge-Website-2048x1463.png"
                                                alt="Valsoft Corporation enters the Marketing Automation space with the acquisition of DemandBridge"
                                              />
                                            </a>
                                            <span
                                              ><a
                                                href="https://www.valsoftcorp.com/news/valsoft-corporation-enters-the-marketing-automation-space-with-the-acquisition-of-demandbridge/"
                                                tabindex="0"
                                                >Valsoft Corporation enters the
                                                Marketing Automation space with
                                                the acquisition of
                                                DemandBridge</a
                                              ></span
                                            >
                                          </div>
                                        </div>
                                        <div
                                          class="slick-slide slick-active"
                                          data-slick-index="4"
                                          aria-hidden="false"
                                          style="width: 370px"
                                          tabindex="0"
                                          role="tabpanel"
                                          id="slick-slide24"
                                        >
                                          <div class="card-acquisitions">
                                            <a
                                              href="https://www.valsoftcorp.com/news/valsoft-corporation-expands-presence-in-energy-management-with-the-acquisition-of-optima-energy-systems/"
                                              tabindex="0"
                                            >
                                              <img
                                                src="<?php echo get_template_directory_uri();?>/assets/images/Optima-Website.png"
                                                alt="Valsoft Corporation expands presence in Energy Management with the acquisition of Optima Energy Systems"
                                              />
                                            </a>
                                            <span
                                              ><a
                                                href="https://www.valsoftcorp.com/news/valsoft-corporation-expands-presence-in-energy-management-with-the-acquisition-of-optima-energy-systems/"
                                                tabindex="0"
                                                >Valsoft Corporation expands
                                                presence in Energy Management
                                                with the acquisition of Optima
                                                Energy Systems</a
                                              ></span
                                            >
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    <button
                                      class="slick-next slick-arrow slick-disabled"
                                      aria-label="Next"
                                      type="button"
                                      style=""
                                      aria-disabled="true"
                                    >
                                      Next
                                    </button>
                                    <ul
                                      class="slick-dots"
                                      style=""
                                      role="tablist"
                                    >
                                      <li class="" role="presentation">
                                        <button
                                          type="button"
                                          role="tab"
                                          id="slick-slide-control20"
                                          aria-controls="slick-slide20"
                                          aria-label="1 of 2"
                                          tabindex="-1"
                                        >
                                          1
                                        </button>
                                      </li>
                                      <li
                                        role="presentation"
                                        class="slick-active"
                                      >
                                        <button
                                          type="button"
                                          role="tab"
                                          id="slick-slide-control21"
                                          aria-controls="slick-slide23"
                                          aria-label="2 of 2"
                                          tabindex="-1"
                                        >
                                          2
                                        </button>
                                      </li>
                                    </ul>
                                  </div>
                                  <script>
                                    const populateCarouselAcquisition = () => {
                                      const acquisitionsCollection = [
                                        {
                                          imageUrl:
                                            "assets/images/Fusion-Website.jpg",
                                          title:
                                            "Valsoft Corporation Strengthens Its Process & Manufacturing Portfolio With the Acquisition of Fusion",
                                          link: "/news/valsoft-corporation-strengthens-its-process-manufacturing-portfolio-with-the-acquisition-of-fusion/",
                                          category: "ACQUISITIONS",
                                          categoryLink:
                                            "/news/category/acquisitions/",
                                        },
                                        {
                                          imageUrl:
                                            "assets/images/ICL-Website.jpg",
                                          title:
                                            "Valsoft Corporation enters the Supply Chain Visibility space with the acquisition of ICL",
                                          link: "/news/valsoft-corporation-enters-the-supply-chain-visibility-space-with-the-acquisition-of-icl/",
                                          category: "ACQUISITIONS",
                                          categoryLink:
                                            "/news/category/acquisitions/",
                                        },
                                        {
                                          imageUrl:
                                            "assets/images/JBL-Website.jpg",
                                          title:
                                            "Valsoft Corporation Introduces Its Industrial ERP Portfolio With the Acquisition of JBL Solutions",
                                          link: "/news/valsoft-corporation-introduces-its-industrial-erp-portfolio-with-the-acquisition-of-jbl-solutions/",
                                          category: "ACQUISITIONS",
                                          categoryLink:
                                            "/news/category/acquisitions/",
                                        },
                                        {
                                          imageUrl:
                                            "assets/images/DemandBridge-Website-2048x1463.png",
                                          title:
                                            "Valsoft Corporation enters the Marketing Automation space with the acquisition of DemandBridge",
                                          link: "/news/valsoft-corporation-enters-the-marketing-automation-space-with-the-acquisition-of-demandbridge/",
                                          category: "ACQUISITIONS",
                                          categoryLink:
                                            "/news/category/acquisitions/",
                                        },
                                        {
                                          imageUrl:
                                            "assets/images/Optima-Website.png",
                                          title:
                                            "Valsoft Corporation expands presence in Energy Management with the acquisition of Optima Energy Systems",
                                          link: "/news/valsoft-corporation-expands-presence-in-energy-management-with-the-acquisition-of-optima-energy-systems/",
                                          category: "ACQUISITIONS",
                                          categoryLink:
                                            "/news/category/acquisitions/",
                                        },
                                      ];

                                      const acquisitionsCont =
                                        document.querySelector(
                                          "#acquisitions-container"
                                        );
                                      let acquisitionInnerHTML = "";
                                      acquisitionsCollection.forEach(
                                        (acquisition) => {
                                          acquisitionInnerHTML += `<div>
        <div class="card-acquisitions">
          <a href="${acquisition.link}">
          <img
            src="${acquisition.imageUrl}"
            alt="${acquisition.title}"
          />
          </a>
          <span><a href="${acquisition.link}">${acquisition.title}</a></span>
        </div>
      </div>`;
                                        }
                                      );

                                      acquisitionsCont.innerHTML =
                                        acquisitionInnerHTML;
                                    };
                                    populateCarouselAcquisition();
                                  </script>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                id="sell-company-section"
                class="vc_row wpb_row vc_row-fluid above-footer secondary_bg_color"
              >
                <div
                  class="container custom-container wpb_column vc_column_container vc_col-sm-12"
                >
                  <div class="vc_column-inner">
                    <div class="wpb_wrapper">
                      <div
                        class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-content-middle vc_row-flex"
                      >
                        <div
                          class="sell-column-section wpb_column vc_column_container vc_col-sm-6"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div
                                class="wpb_text_column wpb_content_element title-sell-section"
                              >
                                <div class="wpb_wrapper">
                                  <h2>
                                    Is It Time to Sell Your Software<br />
                                    Company?
                                  </h2>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div
                          class="contact-sell-form wpb_column vc_column_container vc_col-sm-6"
                        >
                          <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                              <div class="wpb_text_column wpb_content_element">
                                <div class="wpb_wrapper">
                                  <div
                                    class="wpcf7 js"
                                    id="wpcf7-f1546-p1269-o1"
                                    lang="en-US"
                                    dir="ltr"
                                  >
                                    <div class="screen-reader-response">
                                      <p
                                        role="status"
                                        aria-live="polite"
                                        aria-atomic="true"
                                      ></p>
                                      <ul></ul>
                                    </div>
                                    <form
                                      action="/#wpcf7-f1546-p1269-o1"
                                      method="post"
                                      class="wpcf7-form init"
                                      aria-label="Contact form"
                                      novalidate="novalidate"
                                      data-status="init"
                                    >
                                      <div style="display: none">
                                        <input
                                          type="hidden"
                                          name="_wpcf7"
                                          value="1546"
                                        />
                                        <input
                                          type="hidden"
                                          name="_wpcf7_version"
                                          value="5.8.4"
                                        />
                                        <input
                                          type="hidden"
                                          name="_wpcf7_locale"
                                          value="en_US"
                                        />
                                        <input
                                          type="hidden"
                                          name="_wpcf7_unit_tag"
                                          value="wpcf7-f1546-p1269-o1"
                                        />
                                        <input
                                          type="hidden"
                                          name="_wpcf7_container_post"
                                          value="1269"
                                        />
                                        <input
                                          type="hidden"
                                          name="_wpcf7_posted_data_hash"
                                          value=""
                                        />
                                        <input
                                          type="hidden"
                                          name="_wpcf7_recaptcha_response"
                                          value="03AFcWeA7Dur6U8tAA9uPZmVAO5eZ6kDIZiZ1uJ4X_bpyrUeg-2t4piwmnYiXiVWSD-O6TNSYANkrkPwjvbdJ-5RBlitWGLk0xKISekyCpb0cs1q9T9sCSPGaw00bfWTXO8SrlzUDahQb28JBMMO0RKt_CvJPwxHPU3e6dQE71DpIyliWnO23BNtZD03AyJWr0a_b7b4ZgQ0-2rL9wX7x387K9fRwFWpmPKn6S2fefvAKlZadjNnaknM-Jo651ZyU8zlPvcRCp6wmw8HMZ2PWPZJIa6siA7p4h6PLBpc71ElMpTrIv_SfA4OvpbWRkKA-OSnSqnmNY89vCmLeDFj0s7LygFo8ufYyxDcDtsSpo10WAMEDw33oifVnAK2LgAL_7NDptzKX3ylogLMABx45r-uIXSBhSOFIZXT1Vuw4uUGfznd_Su-myBKscOKR8TfMew1NwfpkCedos6F2kNMWNOy4ilRVIC1gIeAO8yjYnyVi55Iz_qSqpCjlbX4ckqW3WNaEyzDMoTwvEqc_BvYST8Dl0wSMmdaOaWC0hzuAtp3UJsbcTxmjGcvRR1IF_TC-JjClBkXHKlKRLqkW6_NLjxr7aLLCHKbOAbV2ezCwf3Gc_8Z9YLucyPcoij5BGechgBh8qMCIr1JJ1"
                                        />
                                      </div>
                                      <h2>Send Us a Message</h2>
                                      <div class="input-group">
                                        <p>
                                          <span
                                            class="wpcf7-form-control-wrap"
                                            data-name="your-name"
                                            ><input
                                              size="40"
                                              class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
                                              aria-required="true"
                                              aria-invalid="false"
                                              placeholder="Name"
                                              type="text"
                                              name="your-name"
                                          /></span>
                                        </p>
                                      </div>
                                      <div class="input-group">
                                        <p>
                                          <span
                                            class="wpcf7-form-control-wrap"
                                            data-name="your-email"
                                            ><input
                                              size="40"
                                              class="wpcf7-form-control wpcf7-email wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-email"
                                              aria-required="true"
                                              aria-invalid="false"
                                              placeholder="Email"
                                              type="email"
                                              name="your-email"
                                          /></span>
                                        </p>
                                      </div>
                                      <div class="input-group">
                                        <p>
                                          <span
                                            class="wpcf7-form-control-wrap"
                                            data-name="your-company"
                                            ><input
                                              size="40"
                                              class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
                                              aria-required="true"
                                              aria-invalid="false"
                                              placeholder="Company"
                                              type="text"
                                              name="your-company"
                                          /></span>
                                        </p>
                                      </div>
                                      <div class="input-group">
                                        <p>
                                          <span
                                            class="wpcf7-form-control-wrap"
                                            data-name="your-message"
                                          >
                                            <textarea
                                              cols="40"
                                              rows="10"
                                              class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required"
                                              aria-required="true"
                                              aria-invalid="false"
                                              placeholder="Message"
                                              name="your-message"
                                            ></textarea>
                                          </span>
                                        </p>
                                      </div>
                                      <div class="input-group submit-group">
                                        <div class="button-container">
                                          <p>
                                            <input
                                              class="wpcf7-form-control wpcf7-submit has-spinner button size-sm fullwidth white-text"
                                              type="submit"
                                              value="Submit"
                                            /><span
                                              class="wpcf7-spinner"
                                            ></span>
                                          </p>
                                        </div>
                                      </div>
                                      <div class="clearfix"></div>
                                      <div class="recaptcha-privacy-terms">
                                        <p>
                                          This site is protected by reCAPTCHA
                                          and the Google
                                          <a
                                            href="https://policies.google.com/privacy"
                                            target="_blank"
                                            >Privacy Policy</a
                                          >
                                          and
                                          <a
                                            href="https://policies.google.com/terms"
                                            target="_blank"
                                            >Terms of Service</a
                                          >
                                          apply.
                                        </p>
                                      </div>
                                      <div
                                        class="wpcf7-response-output"
                                        aria-hidden="true"
                                      ></div>
                                      <input
                                        type="hidden"
                                        name="vx_width"
                                        value="1680"
                                      /><input
                                        type="hidden"
                                        name="vx_height"
                                        value="1050"
                                      /><input
                                        type="hidden"
                                        name="vx_url"
                                        value="https://www.valsoftcorp.com/"
                                      />
                                    </form>
                                  </div>
                                </div>
                              </div>
                              <div
                                class="wpb_raw_code wpb_content_element wpb_raw_html"
                              >
                                <div class="wpb_wrapper"></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </article>
        </div>
<?php get_footer(); ?>        