
(function () {
  var b = {
      "@context": "https://schema.org",
      "@type": "WebPage",
      name: "Valsoft Corporation - Acquirers and Builders of Vertical Market Software",
      description:
        "Valsoft\x27s focus is to acquire and grow vertical software businesses that provide mission-critical solutions in their respective niche or market.",
    },
    a = document.createElement("script");
  a.type = "application/ld+json";
  a.innerHTML = JSON.stringify(b);
  document.getElementsByTagName("head")[0].appendChild(a);
})(document);
